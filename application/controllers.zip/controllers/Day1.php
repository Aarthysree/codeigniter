<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Day1 extends CI_Controller{
    public function mainpage(){
                echo "I am main page";
    }
    public function quotes(){
        echo "Have a good day";
    }
}
?>