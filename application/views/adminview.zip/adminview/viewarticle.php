<?php $this->load->view("adminview/header"); ?>
<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h2>View Article</h2>
    
</main>



<?php $this->load->view("adminview/footer.php"); ?>