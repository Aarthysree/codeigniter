<head>Login</head>

<body>
    <form method="post">
        <label>Username</label>
        <input type="text" name="username" id="username"><br><br>
        <label>Password</label>
        <input type="password" name="password" id="password"><br><br>
        <button type="submit" name="submit" id="submit">Submit</button>
    </form>
    
</body>