<h3>view products</h3>
<b>productname</b>
<?php echo $product->product_name;?></p>
<b>price</b>
<?php echo $product->price;?>
<b>brandname</b>
<?php echo $product->brand_name;?>
