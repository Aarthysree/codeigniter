<div id="content">
    <?php echo heading("Welcome to my site",1)?>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.</p>
</div>