<?php 
  class MemberModel extends CI_model{
    public function Member_data(){
       return $member_name="Hardin";
    }
  }

?>