<?php 
   Class Model_name extends CI_Model { 
	
      Public function __construct() { 
         parent::__construct(); 
      } 
   } 
?> 