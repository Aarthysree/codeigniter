<?php 
class StudentModel extends CI_Model{
    public function student_data(){
        return $stud_name="Hardin  ";
    }
    private function student_class(){
        return $stud_class="BE EEE";
    }
}
?>