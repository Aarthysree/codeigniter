<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Units extends CI_Controller{
    public function __construct()
    {
       parent::__construct();
       $this->load->model('UnitModel');
    }
    public function index(){
        $this->load->view('viewunit');
    }
    function addunits()
    {
        $this->load->view('addunits');
    }
    function addunits_post()
    {
        print_r($_POST);

        $name = $_POST['name'];
        $status = $_POST['status'];
        $query = $this->db->query("INSERT INTO `units`(`name`, `status`) VALUES ('$name','$status')");
        if ($query) {
            $this->session->set_flashdata('inserted', 'yes');
            redirect('units/viewunits');
        } else {
            $this->session->set_flashdata('inserted', 'no');
            redirect('units/addunits');
        }
    }
    //public function store()
//    {
//       $data = array(
//          "name" => $this->input->post('name'),
//          "status" => $this->input->post('status'),
//          );

//       $this->CatModel->insert($data);

//       redirect(base_url('index.php/category'));
//    }
    function editunits($id)
    {
        $data['data'] = $this->UnitModel->find_record_by_id($id);
        $this->load->view('editunits', $data);
    }
    public function update($id)
   {
      $data1 = array(
         "name" => $this->input->post('name'),
         "status" => $this->input->post('status'),
        );

      $this->UnitModel->update($data1, $id);

      redirect(base_url('index.php/units'));
   }
   function viewunits()
   {
       $query = $this->db->query('SELECT * FROM `units`');
       $data['result']= $query->result_array();
       $this->load->view('viewunits',$data);
   }
   function unitview()
   {
       $this->load->view('unitview');
   }
   function deleteunits($id)
   {
       $this->UnitModel->deleteunits($id);

       redirect(base_url('index.php/units'));
   }
}

?>