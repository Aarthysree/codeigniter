<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Products extends CI_Controller{
    public function __construct()
    {
       parent::__construct();
       $this->load->model('ProModel');
    }
    public function index(){
        $this->load->view('viewproducts');
    }
    function addproducts()
    {
        $this->load->view('addproducts');
    }
    function addproducts_post()
    {
        print_r($_POST);

        $name = $_POST['name'];
        $status = $_POST['status'];
        $query = $this->db->query("INSERT INTO `products`(`name`, `status`) VALUES ('$name','$status')");
        if ($query) {
            $this->session->set_flashdata('inserted', 'yes');
            redirect('products/viewproducts');
        } else {
            $this->session->set_flashdata('inserted', 'no');
            redirect('products/addproducts');
        }
    }
    //public function store()
//    {
//       $data = array(
//          "name" => $this->input->post('name'),
//          "status" => $this->input->post('status'),
//          );

//       $this->CatModel->insert($data);

//       redirect(base_url('index.php/category'));
//    }
    function editproducts($id)
    {
        $data['data'] = $this->UnitModel->find_record_by_id($id);
        $this->load->view('editproducts', $data);
    }
    public function update($id)
   {
      $data1 = array(
         "name" => $this->input->post('name'),
         "status" => $this->input->post('status'),
        );

      $this->UnitModel->update($data1, $id);

      redirect(base_url('index.php/products'));
   }
   function viewproducts()
   {
       $query = $this->db->query('SELECT * FROM `products`');
       $data['result']= $query->result_array();
       $this->load->view('viewproducts',$data);
   }
   function unitview()
   {
       $this->load->view('unitview');
   }
   function deleteproducts($id)
   {
       $this->UnitModel->deleteproducts($id);

       redirect(base_url('index.php/products'));
   }
}

?>