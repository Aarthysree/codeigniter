<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Category extends CI_Controller{
   
    public function index(){
        $this->load->view('dashview');
    }
    function addcategory()
    {
        $this->load->view('addcategory');
    }
    function addcategory_post()
    {
        print_r($_POST);

        $name = $_POST['name'];
        $status = $_POST['status'];
        $query = $this->db->query("INSERT INTO `units`(`name`, `status`) VALUES ('$name','$status')");
        if ($query) {
            $this->session->set_flashdata('inserted', 'yes');
            redirect('category/viewcategory');
        } else {
            $this->session->set_flashdata('inserted', 'no');
            redirect('category/addcategory');
        }
    }
//     public function store()
//    {
//       $data = array(
//          "name" => $this->input->post('name'),
//          "status" => $this->input->post('status'),
//          );

//       $this->CatModel->insert($data);

//       redirect(base_url('index.php/category'));
//    }

    function editcategory($id)
    {
        $data['data'] = $this->CatModel->find_record_by_id($id);
        $this->load->view('editcategory', $data);
    }
    public function update($id)
   {
      $data1 = array(
         "name" => $this->input->post('name'),
         "status" => $this->input->post('status'),
        );

      $this->CatModel->update($data1, $id);

      redirect(base_url('index.php/category'));
   }
    function viewcategory()
    {
        $query = $this->db->query('SELECT * FROM `category`');
        $data['result']= $query->result_array();
        $this->load->view('viewcategory',$data);
    }
    function dashview()
    {
        $this->load->view('dashview');
    }
    
    function deletecategory($id)
    {
        $this->CatModel->deletecategory($id);

        redirect(base_url('index.php/category'));
    }

}